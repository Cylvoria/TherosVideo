package com.theros.video

import android.app.Application
import android.content.Context
import android.util.Log
import java.io.File

class TherosApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Crash.install(this)
    }
}

/** Saves the stack trace of a crash so the app can show it on the next launch. */
object Crash {
    private fun file(ctx: Context) = File(ctx.filesDir, "crash.txt")

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { file(app).writeText("Thread: ${t.name}\n" + Log.getStackTraceString(e)) } catch (x: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }

    fun take(ctx: Context): String? {
        return try {
            val f = file(ctx)
            if (!f.exists()) null else f.readText().take(6000).also { f.delete() }
        } catch (t: Throwable) { null }
    }
}
