package com.theros.video

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object VideoLibrary {
    /** Every video file MediaStore knows about. */
    fun load(ctx: Context): List<Video> {
        val out = ArrayList<Video>()
        val coll: Uri = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE, MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media.MIME_TYPE,
        )
        ctx.contentResolver.query(coll, proj, null, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val iT = c.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
            val iD = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val iA = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val iS = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val iW = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
            val iH = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
            val iN = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val iP = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
            val iB = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            val iM = c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val name = c.getString(iN) ?: ""
                val title = c.getString(iT)?.takeIf { it.isNotBlank() }
                    ?: name.substringBeforeLast('.').takeIf { it.isNotBlank() } ?: "Untitled"
                val path = c.getString(iP) ?: ""
                val folder = c.getString(iB)?.takeIf { it.isNotBlank() }
                    ?: path.substringBeforeLast('/', "").substringAfterLast('/').takeIf { it.isNotBlank() }
                    ?: "Other"
                out.add(
                    Video(
                        id = id, title = title, duration = c.getLong(iD), added = c.getLong(iA),
                        size = c.getLong(iS), width = c.getInt(iW), height = c.getInt(iH),
                        uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                        path = path, fileName = name, folder = folder, mime = c.getString(iM) ?: "video/*",
                    )
                )
            }
        }
        return out
    }
}

/**
 * Walks the phone's storage for video files that MediaStore does not know about yet
 * (copied in by Termux, downloaders, file managers...) and asks Android to index them.
 */
object Scanner {
    private val EXT = setOf(
        "mp4", "mkv", "webm", "avi", "mov", "m4v", "3gp", "3g2", "ts", "m2ts", "mts", "flv",
        "wmv", "mpg", "mpeg", "ogv", "vob", "divx",
    )

    private fun roots(ctx: Context): List<File> {
        val out = LinkedHashMap<String, File>()
        try {
            val p = Environment.getExternalStorageDirectory()
            out[p.absolutePath] = p
        } catch (t: Throwable) { }
        try {
            ctx.getExternalFilesDirs(null).forEach { f ->
                if (f == null) return@forEach
                val path = f.absolutePath
                val i = path.indexOf("/Android/")
                if (i > 0) out.putIfAbsent(path.substring(0, i), File(path.substring(0, i)))
            }
        } catch (t: Throwable) { }
        return out.values.toList()
    }

    private fun walk(ctx: Context, budgetMs: Long): List<String> {
        val found = ArrayList<String>()
        val deadline = SystemClock.uptimeMillis() + budgetMs
        val rootList = roots(ctx)
        val rootPaths = rootList.map { it.absolutePath }.toSet()
        val stack = ArrayDeque<File>()
        rootList.forEach { stack.addLast(it) }
        var dirs = 0
        while (stack.isNotEmpty() && SystemClock.uptimeMillis() < deadline && dirs < 20000) {
            val d = stack.removeLast()
            dirs++
            val kids = (try { d.listFiles() } catch (t: Throwable) { null }) ?: continue
            for (f in kids) {
                val n = f.name
                if (n.startsWith(".")) continue
                if (f.isDirectory) {
                    if (n == "Android" && rootPaths.contains(d.absolutePath)) continue
                    stack.addLast(f)
                } else {
                    val e = n.substringAfterLast('.', "").lowercase()
                    if (e in EXT && f.length() > 0L) found.add(f.absolutePath)
                }
            }
        }
        return found
    }

    /** Returns how many files that were missing from MediaStore have been handed to the media scanner. */
    fun scanMissing(ctx: Context, known: Set<String>): Int {
        val missing = walk(ctx, 20_000).filter { it !in known }
        if (missing.isEmpty()) return 0
        val latch = CountDownLatch(missing.size)
        try {
            MediaScannerConnection.scanFile(ctx, missing.toTypedArray(), null) { _, _ -> latch.countDown() }
            latch.await(25, TimeUnit.SECONDS)
        } catch (t: Throwable) { }
        return missing.size
    }
}

/** Video thumbnails with a small in-memory cache. */
object Thumbs {
    private val cache = object : LruCache<Long, Bitmap>(((Runtime.getRuntime().maxMemory() / 1024) / 8).toInt()) {
        override fun sizeOf(key: Long, value: Bitmap) = value.byteCount / 1024
    }

    fun peek(v: Video): Bitmap? = cache.get(v.id)

    fun get(ctx: Context, v: Video): Bitmap? {
        cache.get(v.id)?.let { return it }
        var b: Bitmap? = null
        if (Build.VERSION.SDK_INT >= 29) {
            b = try { ctx.contentResolver.loadThumbnail(v.uri, Size(480, 270), null) } catch (t: Throwable) { null }
        } else {
            b = try {
                MediaStore.Video.Thumbnails.getThumbnail(ctx.contentResolver, v.id, MediaStore.Video.Thumbnails.MINI_KIND, null)
            } catch (t: Throwable) { null }
        }
        if (b == null) b = frame(ctx, v)
        if (b != null) cache.put(v.id, b)
        return b
    }

    private fun frame(ctx: Context, v: Video): Bitmap? {
        return try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, v.uri)
                val at = if (v.duration > 20_000) 5_000_000L else 500_000L
                val f = r.getFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
                val w = 480
                val h = (f.height * (w / f.width.toFloat())).toInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(f, w, h, true)
            } finally { r.release() }
        } catch (t: Throwable) { null }
    }
}
