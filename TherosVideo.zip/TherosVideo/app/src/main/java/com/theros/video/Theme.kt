package com.theros.video

import android.graphics.Color as AColor
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import android.app.Activity

val PRESETS: List<Pair<String, Long>> = listOf(
    "Violet" to 0xFF7C4DFF, "Ocean" to 0xFF00B0FF, "Mint" to 0xFF1DE9B6, "Rose" to 0xFFFF4081,
    "Sunset" to 0xFFFF6E40, "Lime" to 0xFF9CCC65, "Gold" to 0xFFFFC107, "Crimson" to 0xFFE53935,
)

val GRADS: List<Triple<String, Long, Long>> = listOf(
    Triple("Aurora", 0xFF7C4DFF, 0xFF00E5FF), Triple("Sunset", 0xFFFF512F, 0xFFF09819),
    Triple("Bubblegum", 0xFFFF6FD8, 0xFF3813C8), Triple("Ocean", 0xFF2193B0, 0xFF6DD5ED),
    Triple("Mojito", 0xFF1DE9B6, 0xFFB2FF59), Triple("Neon", 0xFFF72585, 0xFF4361EE),
    Triple("Candy", 0xFFFF9A9E, 0xFFA18CD1), Triple("Ember", 0xFFF83600, 0xFFFFC837),
)

enum class ThemeMode { PRESET, GRADIENT, WHEEL }
enum class DarkMode { SYSTEM, DARK, LIGHT }

object ThemeState {
    var mode by mutableStateOf(ThemeMode.PRESET)
    var dark by mutableStateOf(DarkMode.SYSTEM)
    var presetIdx by mutableIntStateOf(0)
    var gradIdx by mutableIntStateOf(0)
    var wheelA by mutableIntStateOf(0xFF7C4DFF.toInt())
    var wheelB by mutableIntStateOf(0xFF00E5FF.toInt())
    var wheelGradient by mutableStateOf(false)

    fun load() {
        mode = ThemeMode.values().getOrElse(Prefs.int("t_mode", 0)) { ThemeMode.PRESET }
        dark = DarkMode.values().getOrElse(Prefs.int("t_dark", 0)) { DarkMode.SYSTEM }
        presetIdx = Prefs.int("t_preset", 0).coerceIn(PRESETS.indices)
        gradIdx = Prefs.int("t_grad", 0).coerceIn(GRADS.indices)
        wheelA = Prefs.int("t_a", 0xFF7C4DFF.toInt())
        wheelB = Prefs.int("t_b", 0xFF00E5FF.toInt())
        wheelGradient = Prefs.bool("t_wg", false)
    }

    fun commit() {
        Prefs.put("t_mode", mode.ordinal); Prefs.put("t_dark", dark.ordinal)
        Prefs.put("t_preset", presetIdx); Prefs.put("t_grad", gradIdx)
        Prefs.put("t_a", wheelA); Prefs.put("t_b", wheelB); Prefs.put("t_wg", wheelGradient)
    }

    fun accents(): Pair<Color, Color> = when (mode) {
        ThemeMode.PRESET -> Color(PRESETS[presetIdx].second).let { it to shift(it) }
        ThemeMode.GRADIENT -> GRADS[gradIdx].let { Color(it.second) to Color(it.third) }
        ThemeMode.WHEEL -> if (wheelGradient) Color(wheelA) to Color(wheelB) else Color(wheelA).let { it to shift(it) }
    }
}

private fun shift(c: Color, deg: Float = 40f): Color {
    val hsv = FloatArray(3)
    AColor.colorToHSV(c.toArgb(), hsv)
    hsv[0] = (hsv[0] + deg) % 360f
    return Color(AColor.HSVToColor(hsv))
}

@Immutable
class Pal(
    val accent: Color, val accent2: Color, val bg: Color, val surface: Color, val card: Color,
    val text: Color, val subtle: Color, val onAccent: Color, val dark: Boolean,
) {
    val brush: Brush get() = Brush.linearGradient(listOf(accent, accent2))
    val hBrush: Brush get() = Brush.horizontalGradient(listOf(accent, accent2))
}

val LocalPal = compositionLocalOf<Pal> { error("Pal not provided") }

private fun buildPal(a: Color, b: Color, dark: Boolean): Pal {
    val onA = if (a.luminance() > 0.5f) Color(0xFF14141F) else Color.White
    return if (dark) Pal(
        a, b, lerp(Color(0xFF0A0A12), a, 0.10f), lerp(Color(0xFF14141F), a, 0.14f), lerp(Color(0xFF1C1C2A), a, 0.18f),
        Color(0xFFF4F4FA), Color(0xFFF4F4FA).copy(alpha = 0.6f), onA, true,
    ) else Pal(
        a, b, lerp(Color.White, a, 0.07f), lerp(Color.White, a, 0.10f), lerp(Color.White, a, 0.14f),
        Color(0xFF14141F), Color(0xFF14141F).copy(alpha = 0.6f), onA, false,
    )
}

@Composable
fun TherosTheme(content: @Composable () -> Unit) {
    val dark = when (ThemeState.dark) {
        DarkMode.SYSTEM -> isSystemInDarkTheme()
        DarkMode.DARK -> true
        DarkMode.LIGHT -> false
    }
    val (t1, t2) = ThemeState.accents()
    val c1 by animateColorAsState(t1, tween(700), label = "c1")
    val c2 by animateColorAsState(t2, tween(700), label = "c2")
    val pal = remember(c1, c2, dark) { buildPal(c1, c2, dark) }
    val scheme = if (dark) darkColorScheme(
        primary = c1, onPrimary = pal.onAccent, secondary = c2, background = pal.bg, surface = pal.surface,
        onSurface = pal.text, onBackground = pal.text, surfaceVariant = pal.card, onSurfaceVariant = pal.subtle,
    ) else lightColorScheme(
        primary = c1, onPrimary = pal.onAccent, secondary = c2, background = pal.bg, surface = pal.surface,
        onSurface = pal.text, onBackground = pal.text, surfaceVariant = pal.card, onSurfaceVariant = pal.subtle,
    )
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window ?: return@SideEffect
        val ic = WindowCompat.getInsetsController(w, view)
        ic.isAppearanceLightStatusBars = !dark
        ic.isAppearanceLightNavigationBars = !dark
    }
    CompositionLocalProvider(LocalPal provides pal) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
