@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.theros.video

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.provider.OpenableColumns
import androidx.compose.runtime.*
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.util.Locale

/** One selectable audio or subtitle track. */
class TrackOpt(val group: Tracks.Group, val index: Int, val label: String, val selected: Boolean)

/** Everything the player screen needs: the ExoPlayer plus Compose-observable state. */
class VPlayer(private val ctx: Context) {
    val exo: ExoPlayer = ExoPlayer.Builder(ctx).build().apply {
        setAudioAttributes(
            androidx.media3.common.AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
            true, // pause when another app takes audio focus, resume when it gives it back
        )
        setHandleAudioBecomingNoisy(true)
    }

    var current by mutableStateOf<Video?>(null); private set
    var title by mutableStateOf(""); private set
    var isPlaying by mutableStateOf(false); private set
    var buffering by mutableStateOf(false); private set
    var ended by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var position by mutableLongStateOf(0L); private set
    var duration by mutableLongStateOf(0L); private set
    var videoW by mutableIntStateOf(0); private set
    var videoH by mutableIntStateOf(0); private set
    var pixelRatio by mutableFloatStateOf(1f); private set
    var cue by mutableStateOf(""); private set
    var audioTracks by mutableStateOf<List<TrackOpt>>(emptyList()); private set
    var textTracks by mutableStateOf<List<TrackOpt>>(emptyList()); private set
    var textOff by mutableStateOf(true); private set
    var speed by mutableFloatStateOf(1f); private set
    var loopOne by mutableStateOf(false); private set
    var abA by mutableLongStateOf(-1L); private set
    var abB by mutableLongStateOf(-1L); private set
    var sleepAt by mutableLongStateOf(0L); private set
    var sleepEndOfVideo by mutableStateOf(false); private set

    /** Called when the video size becomes known (the activity uses it to pick an orientation). */
    var onSize: (() -> Unit)? = null

    private var extraSubs: List<MediaItem.SubtitleConfiguration> = emptyList()
    private var lastSave = 0L

    val hasNext: Boolean get() = Queue.index < Queue.items.size - 1
    val hasPrev: Boolean get() = Queue.index > 0

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }

        override fun onPlaybackStateChanged(state: Int) {
            buffering = state == Player.STATE_BUFFERING
            if (state == Player.STATE_READY) {
                val d = exo.duration
                if (d > 0) duration = d
                ended = false
            }
            if (state == Player.STATE_ENDED) {
                ended = true
                persist()
                if (sleepEndOfVideo) {
                    sleepEndOfVideo = false
                } else if (Cfg.autoNext && hasNext) {
                    next()
                }
            }
        }

        override fun onVideoSizeChanged(v: VideoSize) {
            videoW = v.width; videoH = v.height
            pixelRatio = if (v.pixelWidthHeightRatio > 0f) v.pixelWidthHeightRatio else 1f
            onSize?.invoke()
        }

        override fun onTracksChanged(tracks: Tracks) { readTracks(tracks) }

        override fun onCues(cueGroup: CueGroup) {
            cue = cueGroup.cues.joinToString("\n") { it.text?.toString() ?: "" }.trim()
        }

        override fun onPlayerError(e: PlaybackException) {
            error = "This video can't be played (" + e.errorCodeName + ")"
        }
    }

    init { exo.addListener(listener) }

    // ---------- loading ----------
    private fun sidecars(v: Video): List<MediaItem.SubtitleConfiguration> {
        val out = ArrayList<MediaItem.SubtitleConfiguration>()
        if (v.path.isEmpty()) return out
        try {
            val base = v.path.substringBeforeLast('.')
            val tries = listOf(
                "srt" to MimeTypes.APPLICATION_SUBRIP, "vtt" to MimeTypes.TEXT_VTT,
                "ass" to MimeTypes.TEXT_SSA, "ssa" to MimeTypes.TEXT_SSA,
            )
            for ((ext, mime) in tries) {
                val f = File("$base.$ext")
                if (f.exists() && f.canRead()) {
                    out.add(
                        MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                            .setMimeType(mime).setLanguage("und").setLabel(f.name).build()
                    )
                }
            }
        } catch (t: Throwable) { }
        return out
    }

    private fun buildItem(v: Video): MediaItem {
        val b = MediaItem.Builder().setUri(v.uri).setMediaId(v.id.toString())
        val subs = sidecars(v) + extraSubs
        if (subs.isNotEmpty()) b.setSubtitleConfigurations(subs)
        return b.build()
    }

    fun playIndex(i: Int, fromStart: Boolean = false) {
        if (i !in Queue.items.indices) return
        persist()
        Queue.index = i
        val v = Queue.items[i]
        current = v
        title = v.title
        error = null; ended = false; cue = ""
        position = 0L; duration = v.duration.coerceAtLeast(0L)
        abA = -1L; abB = -1L
        extraSubs = emptyList()
        audioTracks = emptyList(); textTracks = emptyList()
        val saved = if (!fromStart && Cfg.resume) Store.savedPos(v.id) else 0L
        val dur = if (v.duration > 0) v.duration else Store.savedDur(v.id)
        val start = if (saved > 5000 && (dur <= 0 || saved < dur - 8000)) saved else 0L
        exo.setMediaItem(buildItem(v), start)
        exo.prepare()
        exo.playWhenReady = true
    }

    private fun reload() {
        val v = current ?: return
        val pos = exo.currentPosition
        val play = exo.playWhenReady
        exo.setMediaItem(buildItem(v), pos)
        exo.prepare()
        exo.playWhenReady = play
    }

    fun addSubtitle(uri: Uri) {
        val v = current ?: return
        var name = ""
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: ""
            }
        } catch (t: Throwable) { }
        val mime = when (name.substringAfterLast('.', "").lowercase()) {
            "vtt" -> MimeTypes.TEXT_VTT
            "ass", "ssa" -> MimeTypes.TEXT_SSA
            "ttml", "xml", "dfxp" -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        extraSubs = extraSubs + MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime).setLanguage("und").setLabel(name.ifBlank { "External subtitles" })
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        textOff = false
        if (v.id != Long.MIN_VALUE) reload()
    }

    // ---------- tracks ----------
    private fun langName(l: String?): String {
        if (l.isNullOrBlank() || l == "und") return ""
        return try { Locale.forLanguageTag(l).displayLanguage } catch (t: Throwable) { l }
    }

    private fun readTracks(t: Tracks) {
        val a = ArrayList<TrackOpt>()
        val s = ArrayList<TrackOpt>()
        for (g in t.groups) {
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                if (g.type == C.TRACK_TYPE_AUDIO) {
                    val lang = langName(f.language)
                    val ch = when (f.channelCount) {
                        1 -> "Mono"; 2 -> "Stereo"; 6 -> "5.1"; 8 -> "7.1"
                        else -> if (f.channelCount > 0) "${f.channelCount}ch" else ""
                    }
                    val codec = (f.sampleMimeType ?: "").substringAfter('/').uppercase()
                    val parts = listOf(f.label ?: lang, ch, codec).filter { !it.isNullOrBlank() }
                    a.add(TrackOpt(g, i, if (parts.isEmpty()) "Track ${a.size + 1}" else parts.joinToString(" - "), g.isTrackSelected(i)))
                } else if (g.type == C.TRACK_TYPE_TEXT) {
                    val lang = langName(f.language)
                    val name = f.label ?: lang
                    s.add(TrackOpt(g, i, if (name.isNullOrBlank()) "Subtitle ${s.size + 1}" else name, g.isTrackSelected(i)))
                }
            }
        }
        audioTracks = a
        textTracks = s
        if (s.any { it.selected }) textOff = false
    }

    fun selectAudio(o: TrackOpt) {
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(o.group.mediaTrackGroup, o.index)).build()
    }

    fun selectText(o: TrackOpt?) {
        val b = exo.trackSelectionParameters.buildUpon()
        if (o == null) {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            textOff = true
            cue = ""
        } else {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            b.setOverrideForType(TrackSelectionOverride(o.group.mediaTrackGroup, o.index))
            textOff = false
        }
        exo.trackSelectionParameters = b.build()
    }

    // ---------- controls ----------
    fun toggle() {
        if (ended) { replay(); return }
        if (exo.isPlaying || exo.playWhenReady) exo.pause() else exo.play()
    }

    fun replay() { ended = false; exo.seekTo(0L); exo.play() }

    fun seekBy(ms: Long) {
        val d = exo.duration
        val max = if (d > 0) d else Long.MAX_VALUE
        exo.seekTo((exo.currentPosition + ms).coerceIn(0L, max))
    }

    fun next() { if (hasNext) playIndex(Queue.index + 1) }
    fun prev() {
        if (exo.currentPosition > 4000 || !hasPrev) exo.seekTo(0L) else playIndex(Queue.index - 1)
    }

    fun changeSpeed(f: Float) { speed = f; exo.setPlaybackSpeed(f) }
    fun boost(on: Boolean) { exo.setPlaybackSpeed(if (on) Cfg.holdSpeed else speed) }

    fun toggleLoop(): Boolean {
        loopOne = !loopOne
        exo.repeatMode = if (loopOne) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        return loopOne
    }

    /** Tap through: set A, set B (loop starts), clear. Returns a short label for the HUD. */
    fun cycleAB(): String {
        val p = exo.currentPosition
        if (abA < 0) { abA = p; return "A set at ${fmt(p)}" }
        if (abB < 0) {
            if (p <= abA + 500) return "B must be after A"
            abB = p; return "Looping ${fmt(abA)} - ${fmt(abB)}"
        }
        abA = -1L; abB = -1L
        return "A-B loop off"
    }

    fun setSleep(minutes: Int, endOfVideo: Boolean) {
        sleepEndOfVideo = endOfVideo
        sleepAt = if (minutes > 0) SystemClock.elapsedRealtime() + minutes * 60_000L else 0L
    }

    fun tick() {
        position = exo.currentPosition.coerceAtLeast(0L)
        val d = exo.duration
        if (d > 0) duration = d
        if (abA >= 0 && abB > abA && position >= abB) exo.seekTo(abA)
        val now = SystemClock.elapsedRealtime()
        if (sleepAt > 0 && now >= sleepAt) { sleepAt = 0L; exo.pause() }
        if (exo.isPlaying && now - lastSave > 5000) { lastSave = now; persist() }
    }

    fun persist() {
        val v = current ?: return
        if (exo.playbackState == Player.STATE_IDLE) return
        val dur = if (exo.duration > 0) exo.duration else v.duration
        val pos = if (ended && dur > 0) dur else exo.currentPosition
        Store.markPlayed(v.id, pos, dur)
    }

    fun release() {
        persist()
        try { exo.removeListener(listener); exo.release() } catch (t: Throwable) { }
    }
}
