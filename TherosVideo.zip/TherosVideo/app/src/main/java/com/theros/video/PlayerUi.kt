package com.theros.video

import android.os.Build
import android.view.SurfaceView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToInt

/** A short message in the middle of the video (seek amount, brightness, volume...). side: -1 left, 0 top, 1 right. */
class Hud(val icon: Int, val text: String, val frac: Float? = null, val side: Int = 0)

/** Things only the activity can do. */
interface PlayerHost {
    val inPip: Boolean
    fun brightness(): Float
    fun changeBrightness(v: Float)
    fun volume(): Float
    fun changeVolume(f: Float)
    fun enterPip()
    fun applyOrientation(mode: Int)
    fun close()
}

private val ORIENT_NAMES = listOf("Auto (match video)", "Landscape", "Portrait", "System rotation")

private fun speedText(f: Float): String =
    if (f % 1f == 0f) "${f.toInt()}x" else "${(f * 100).roundToInt() / 100f}x"

/** Sizes the surface for the chosen aspect mode inside whatever space the parent gives it. */
private fun Modifier.fitVideo(vw: Int, vh: Int, pr: Float, mode: ResizeMode): Modifier = this.layout { measurable, c ->
    val cw = c.maxWidth
    val ch = c.maxHeight
    val ar = when (mode) {
        ResizeMode.R169 -> 16f / 9f
        ResizeMode.R43 -> 4f / 3f
        else -> if (vw > 0 && vh > 0) vw * pr / vh else 16f / 9f
    }
    val w: Int
    val h: Int
    when (mode) {
        ResizeMode.FILL -> { w = cw; h = ch }
        ResizeMode.ZOOM -> {
            if (cw / ch.toFloat() > ar) { w = cw; h = (cw / ar).roundToInt() } else { h = ch; w = (ch * ar).roundToInt() }
        }
        else -> {
            if (cw / ch.toFloat() > ar) { h = ch; w = (ch * ar).roundToInt() } else { w = cw; h = (cw / ar).roundToInt() }
        }
    }
    val p = measurable.measure(Constraints.fixed(w.coerceAtLeast(1), h.coerceAtLeast(1)))
    layout(cw, ch) { p.place((cw - w) / 2, (ch - h) / 2) }
}

@Composable
fun VideoSurface(vp: VPlayer, mode: ResizeMode) {
    AndroidView(
        factory = { c -> SurfaceView(c).also { vp.exo.setVideoSurfaceView(it) } },
        modifier = Modifier.fitVideo(vp.videoW, vp.videoH, vp.pixelRatio, mode),
    )
    DisposableEffect(Unit) { onDispose { try { vp.exo.clearVideoSurface() } catch (t: Throwable) { } } }
}

@Composable
private fun PBtn(
    res: Int, modifier: Modifier = Modifier, size: Dp = 44.dp, iconSize: Dp = 24.dp,
    alpha: Float = 1f, onClick: () -> Unit,
) {
    Box(modifier.size(size).alpha(alpha).clip(CircleShape).bounceClick(onClick), Alignment.Center) {
        Ic(res, Color.White, iconSize)
    }
}

@Composable
private fun ToolBtn(res: Int, active: Boolean = false, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(40.dp).clip(CircleShape).bounceClick(onClick)
            .background(if (active) pal.accent else Color.White.copy(alpha = 0.14f)),
        Alignment.Center,
    ) { Ic(res, if (active) pal.onAccent else Color.White, 20.dp) }
}

@Composable
private fun ToolChip(text: String, active: Boolean = false, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.height(40.dp).clip(CircleShape).bounceClick(onClick)
            .background(if (active) pal.accent else Color.White.copy(alpha = 0.14f)).padding(horizontal = 14.dp),
        Alignment.Center,
    ) { Text(text, color = if (active) pal.onAccent else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(vp: VPlayer, host: PlayerHost) {
    val pal = LocalPal.current
    var controls by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var poke by remember { mutableIntStateOf(0) }
    var hud by remember { mutableStateOf<Hud?>(null) }
    var sheet by remember { mutableIntStateOf(0) } // 0 none, 1 speed, 2 audio, 3 subtitles, 4 timer, 5 settings
    var scrub by remember { mutableStateOf<Float?>(null) }
    var boosted by remember { mutableStateOf(false) }
    val modes = ResizeMode.values()
    val resize = modes[Cfg.aspect.coerceIn(0, modes.size - 1)]

    val subPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vp.addSubtitle(uri)
    }

    LaunchedEffect(Unit) {
        while (true) {
            vp.tick()
            delay(if (vp.isPlaying) 200L else 500L)
        }
    }
    LaunchedEffect(controls, vp.isPlaying, poke, sheet) {
        if (controls && vp.isPlaying && sheet == 0) {
            delay(3500)
            controls = false
        }
    }
    LaunchedEffect(hud) {
        if (hud != null) {
            delay(900)
            hud = null
        }
    }

    fun showAspect(m: ResizeMode) { hud = Hud(R.drawable.ic_aspect, m.label) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VideoSurface(vp, resize)

        if (!host.inPip) {
            // ---------- gestures ----------
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        // two-finger pinch: out = zoom to fill, in = fit
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            var start = 0f
                            var fired = false
                            do {
                                val ev = awaitPointerEvent()
                                val pts = ev.changes.filter { it.pressed }
                                if (pts.size >= 2 && !fired) {
                                    val d = (pts[0].position - pts[1].position).getDistance()
                                    if (start == 0f) start = d
                                    else {
                                        val r = d / start
                                        if (r > 1.25f) {
                                            fired = true
                                            Cfg.aspect = ResizeMode.ZOOM.ordinal; Cfg.save(); showAspect(ResizeMode.ZOOM)
                                        } else if (r < 0.8f) {
                                            fired = true
                                            Cfg.aspect = ResizeMode.FIT.ordinal; Cfg.save(); showAspect(ResizeMode.FIT)
                                        }
                                    }
                                    ev.changes.forEach { it.consume() }
                                }
                            } while (ev.changes.any { it.pressed })
                        }
                    }
                    .pointerInput(locked) {
                        detectTapGestures(
                            onTap = { controls = !controls },
                            onDoubleTap = { o ->
                                if (!locked) {
                                    val third = size.width / 3f
                                    val ms = Cfg.seekSecs * 1000L
                                    if (o.x < third) {
                                        vp.seekBy(-ms); hud = Hud(R.drawable.ic_replay, "-${Cfg.seekSecs}s", side = -1)
                                    } else if (o.x > third * 2f) {
                                        vp.seekBy(ms); hud = Hud(R.drawable.ic_forward, "+${Cfg.seekSecs}s", side = 1)
                                    } else vp.toggle()
                                }
                            },
                            onLongPress = {
                                if (!locked) {
                                    boosted = true
                                    vp.boost(true)
                                    hud = Hud(R.drawable.ic_speed, speedText(Cfg.holdSpeed))
                                }
                            },
                            onPress = {
                                tryAwaitRelease()
                                if (boosted) { boosted = false; vp.boost(false) }
                            },
                        )
                    }
                    .then(
                        if (locked) Modifier else Modifier.pointerInput(Unit) {
                            var mode = 0 // 1 seek, 2 brightness, 3 volume
                            var dx = 0f
                            var dy = 0f
                            var startX = 0f
                            var startPos = 0L
                            var startBright = 0.5f
                            var startVol = 0.5f
                            var target = -1L
                            detectDragGestures(
                                onDragStart = { o ->
                                    mode = 0; dx = 0f; dy = 0f; startX = o.x; target = -1L
                                    startPos = vp.exo.currentPosition
                                    startBright = host.brightness()
                                    startVol = host.volume()
                                },
                                onDragEnd = {
                                    if (mode == 1 && target >= 0) vp.exo.seekTo(target)
                                    mode = 0; target = -1L
                                },
                                onDragCancel = { mode = 0; target = -1L },
                                onDrag = { change, amount ->
                                    change.consume()
                                    dx += amount.x; dy += amount.y
                                    if (mode == 0 && (abs(dx) > 28f || abs(dy) > 28f)) {
                                        mode = if (abs(dx) > abs(dy)) 1 else if (startX < size.width / 2f) 2 else 3
                                    }
                                    when (mode) {
                                        1 -> {
                                            val dur = vp.exo.duration
                                            val max = if (dur > 0) dur else Long.MAX_VALUE
                                            val delta = (dx / size.width * 150_000f).toLong()
                                            target = (startPos + delta).coerceIn(0L, max)
                                            val sign = if (delta >= 0) "+" else "-"
                                            hud = Hud(
                                                if (delta >= 0) R.drawable.ic_forward else R.drawable.ic_replay,
                                                "${fmt(target)}   ($sign${fmt(abs(delta))})",
                                                if (dur > 0) target.toFloat() / dur else null,
                                            )
                                        }
                                        2 -> {
                                            val f = (startBright - dy / size.height * 1.2f).coerceIn(0.02f, 1f)
                                            host.changeBrightness(f)
                                            hud = Hud(R.drawable.ic_brightness, "${(f * 100).roundToInt()}%", f, -1)
                                        }
                                        3 -> {
                                            val f = (startVol - dy / size.height * 1.2f).coerceIn(0f, 1f)
                                            host.changeVolume(f)
                                            hud = Hud(R.drawable.ic_volume, "${(f * 100).roundToInt()}%", f, 1)
                                        }
                                        else -> { }
                                    }
                                },
                            )
                        }
                    )
            )

            // ---------- subtitles ----------
            if (vp.cue.isNotBlank()) {
                Box(
                    Modifier.align(Alignment.BottomCenter).displayCutoutPadding()
                        .padding(bottom = if (controls && !locked) 150.dp else 34.dp, start = 24.dp, end = 24.dp),
                ) {
                    Text(
                        vp.cue,
                        modifier = Modifier
                            .then(if (Cfg.subBg) Modifier.background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp)) else Modifier)
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        style = TextStyle(
                            color = Color.White, fontSize = (18f * Cfg.subSize).sp, fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center, shadow = Shadow(Color.Black, Offset(0f, 0f), 8f),
                        ),
                    )
                }
            }

            if (vp.buffering) CircularProgressIndicator(Modifier.align(Alignment.Center).size(52.dp), color = pal.accent)

            // ---------- controls ----------
            AnimatedVisibility(
                visible = controls && !locked, enter = fadeIn(), exit = fadeOut(),
                modifier = Modifier.fillMaxSize(),
            ) {
                Box(Modifier.fillMaxSize()) {
                    Box(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth().height(120.dp)
                            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.75f), Color.Transparent)))
                    )
                    Box(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(190.dp)
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))))
                    )

                    // top bar
                    Row(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth().displayCutoutPadding()
                            .statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        PBtn(R.drawable.ic_back) { host.close() }
                        Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                            Text(vp.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (Queue.items.size > 1) Text("${Queue.index + 1} / ${Queue.items.size}", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                        }
                        PBtn(R.drawable.ic_subtitles) { sheet = 3 }
                        PBtn(R.drawable.ic_music) { sheet = 2 }
                        PBtn(R.drawable.ic_more) { sheet = 5 }
                    }

                    // centre transport
                    Row(
                        Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        PBtn(R.drawable.ic_prev, size = 48.dp, alpha = if (vp.hasPrev) 1f else 0.35f) { vp.prev(); poke++ }
                        Box(Modifier.size(52.dp).clip(CircleShape).bounceClick { vp.seekBy(-Cfg.seekSecs * 1000L); poke++ }, Alignment.Center) {
                            Ic(R.drawable.ic_replay, Color.White, 34.dp)
                            Text("${Cfg.seekSecs}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 3.dp))
                        }
                        Box(
                            Modifier.size(72.dp).clip(CircleShape).bounceClick { vp.toggle(); poke++ }.background(pal.brush),
                            Alignment.Center,
                        ) { Ic(if (vp.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, pal.onAccent, 38.dp) }
                        Box(Modifier.size(52.dp).clip(CircleShape).bounceClick { vp.seekBy(Cfg.seekSecs * 1000L); poke++ }, Alignment.Center) {
                            Ic(R.drawable.ic_forward, Color.White, 34.dp)
                            Text("${Cfg.seekSecs}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 3.dp))
                        }
                        PBtn(R.drawable.ic_next, size = 48.dp, alpha = if (vp.hasNext) 1f else 0.35f) { vp.next(); poke++ }
                    }

                    // bottom: seek bar + tools
                    Column(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().displayCutoutPadding()
                            .navigationBarsPadding().padding(horizontal = 18.dp).padding(bottom = 8.dp),
                    ) {
                        val dur = vp.duration
                        val sc = scrub
                        val frac = sc ?: if (dur > 0) (vp.position.toFloat() / dur).coerceIn(0f, 1f) else 0f
                        val shown = if (sc != null) (sc * dur).toLong() else vp.position
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmt(shown), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            SeekBar(
                                frac, { scrub = it; poke++ },
                                {
                                    val f = scrub
                                    scrub = null
                                    if (f != null && vp.duration > 0) vp.exo.seekTo((f * vp.duration).toLong())
                                },
                                Modifier.weight(1f).padding(horizontal = 8.dp),
                            )
                            Text(if (dur > 0) fmt(dur) else "--:--", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(4.dp))
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ToolBtn(R.drawable.ic_lock) { locked = true; controls = false; hud = Hud(R.drawable.ic_lock, "Controls locked") }
                            ToolChip(speedText(vp.speed), vp.speed != 1f) { sheet = 1 }
                            ToolChip(resize.label) {
                                val n = modes[(Cfg.aspect + 1) % modes.size]
                                Cfg.aspect = n.ordinal; Cfg.save(); showAspect(n); poke++
                            }
                            ToolBtn(R.drawable.ic_rotate) {
                                Cfg.orient = (Cfg.orient + 1) % 4; Cfg.save()
                                host.applyOrientation(Cfg.orient)
                                hud = Hud(R.drawable.ic_rotate, ORIENT_NAMES[Cfg.orient]); poke++
                            }
                            ToolChip(
                                when { vp.abA < 0 -> "A-B"; vp.abB < 0 -> "A ${fmt(vp.abA)}"; else -> "A-B on" },
                                vp.abA >= 0,
                            ) { hud = Hud(R.drawable.ic_repeat, vp.cycleAB()); poke++ }
                            ToolBtn(R.drawable.ic_timer, vp.sleepAt > 0 || vp.sleepEndOfVideo) { sheet = 4 }
                            ToolBtn(R.drawable.ic_repeat_one, vp.loopOne) {
                                val on = vp.toggleLoop()
                                hud = Hud(R.drawable.ic_repeat_one, if (on) "Repeat video: on" else "Repeat video: off"); poke++
                            }
                            if (Build.VERSION.SDK_INT >= 26) ToolBtn(R.drawable.ic_pip) { host.enterPip() }
                        }
                    }
                }
            }

            // lock: only an unlock button
            AnimatedVisibility(
                visible = locked && controls, enter = fadeIn(), exit = fadeOut(),
                modifier = Modifier.align(Alignment.CenterStart).displayCutoutPadding().padding(start = 24.dp),
            ) {
                Box(
                    Modifier.size(58.dp).clip(CircleShape).bounceClick { locked = false; controls = true; poke++ }
                        .background(pal.brush),
                    Alignment.Center,
                ) { Ic(R.drawable.ic_lock_open, pal.onAccent, 26.dp) }
            }

            // HUD
            hud?.let { h ->
                Box(
                    Modifier.align(
                        when (h.side) { -1 -> Alignment.CenterStart; 1 -> Alignment.CenterEnd; else -> Alignment.TopCenter }
                    ).displayCutoutPadding().padding(horizontal = 36.dp, vertical = 40.dp)
                        .clip(RoundedCornerShape(20.dp)).background(Color.Black.copy(alpha = 0.65f))
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Ic(h.icon, Color.White, 22.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(h.text, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        val f = h.frac
                        if (f != null) {
                            Spacer(Modifier.height(8.dp))
                            Box(Modifier.width(110.dp).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.3f))) {
                                Box(Modifier.fillMaxHeight().fillMaxWidth(f.coerceIn(0.02f, 1f)).background(pal.accent))
                            }
                        }
                    }
                }
            }

            // finished
            if (vp.ended && !vp.hasNext && vp.error == null) {
                Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Chip("Replay", true, { vp.replay() }, icon = R.drawable.ic_replay)
                    Chip("Close", false, { host.close() })
                }
            }

            // error
            vp.error?.let { msg ->
                Column(
                    Modifier.align(Alignment.Center).padding(32.dp).clip(RoundedCornerShape(24.dp))
                        .background(Color.Black.copy(alpha = 0.75f)).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Ic(R.drawable.ic_info, Color.White, 36.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(msg, color = Color.White, textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold)
                    Text("The phone may not support this video or audio format.", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (vp.hasNext) Chip("Next video", true, { vp.next() })
                        Chip("Close", false, { host.close() })
                    }
                }
            }
        }
    }

    when (sheet) {
        1 -> SpeedSheet(vp) { sheet = 0 }
        2 -> TrackSheet(
            "Audio track", vp.audioTracks, null, false, {}, { vp.selectAudio(it) },
            { }, { sheet = 0 },
        )
        3 -> TrackSheet(
            "Subtitles", vp.textTracks, "Off", vp.textOff, { vp.selectText(null) }, { vp.selectText(it) },
            { Chip("Load subtitle file...", false, { subPicker.launch("*/*"); sheet = 0 }, icon = R.drawable.ic_subtitles) },
            { sheet = 0 },
        )
        4 -> TimerSheet(vp) { sheet = 0 }
        5 -> SettingsSheet { sheet = 0 }
    }
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(18.dp))
            .then(if (selected) Modifier.background(pal.accent.copy(alpha = 0.16f)) else Modifier)
            .bounceClick(onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, Modifier.weight(1f), color = if (selected) pal.accent else pal.text, fontWeight = FontWeight.SemiBold)
        if (selected) Ic(R.drawable.ic_check, pal.accent, 20.dp)
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun SpeedSheet(vp: VPlayer, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = pal.surface, sheetState = rememberModalBottomSheetState(true)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp).verticalScroll(rememberScrollState())) {
            Text("Playback speed", color = pal.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(
                speedText(vp.speed), color = pal.accent, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )
            Slider(
                value = vp.speed.coerceIn(0.25f, 4f), valueRange = 0.25f..4f,
                onValueChange = { vp.changeSpeed((it * 20f).roundToInt() / 20f) },
                colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent, inactiveTrackColor = pal.accent.copy(alpha = 0.22f)),
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f).forEach { s ->
                    Chip(speedText(s), vp.speed == s, { vp.changeSpeed(s) })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrackSheet(
    title: String, tracks: List<TrackOpt>, offLabel: String?, offSelected: Boolean, onOff: () -> Unit,
    onPick: (TrackOpt) -> Unit, footer: @Composable () -> Unit, onDismiss: () -> Unit,
) {
    val pal = LocalPal.current
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = pal.surface, sheetState = rememberModalBottomSheetState(true)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp).verticalScroll(rememberScrollState())) {
            Text(title, color = pal.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
            if (offLabel != null) OptionRow(offLabel, offSelected) { onOff() }
            tracks.forEach { t -> OptionRow(t.label, t.selected && !(offLabel != null && offSelected)) { onPick(t) } }
            if (tracks.isEmpty() && offLabel == null) Text("No tracks found in this video", color = pal.subtle)
            Spacer(Modifier.height(12.dp))
            footer()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimerSheet(vp: VPlayer, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    val opts = listOf("Off" to 0, "15 minutes" to 15, "30 minutes" to 30, "45 minutes" to 45, "1 hour" to 60, "90 minutes" to 90)
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = pal.surface, sheetState = rememberModalBottomSheetState(true)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp).verticalScroll(rememberScrollState())) {
            Text("Sleep timer", color = pal.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text("Pauses the video when the time is up.", color = pal.subtle, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            opts.forEach { (label, min) ->
                OptionRow(label, if (min == 0) (vp.sleepAt == 0L && !vp.sleepEndOfVideo) else false) {
                    vp.setSleep(min, false); onDismiss()
                }
            }
            OptionRow("At the end of this video", vp.sleepEndOfVideo) { vp.setSleep(0, true); onDismiss() }
        }
    }
}
