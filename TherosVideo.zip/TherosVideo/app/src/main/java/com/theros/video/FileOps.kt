package com.theros.video

import android.app.RecoverableSecurityException
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.IntentSender
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.io.IOException

/**
 * Rename / delete video files through MediaStore.
 * Android 11+: the system shows its own "Allow Theros Video to ...?" dialog ([askUser]).
 * Android 10: same via RecoverableSecurityException. Android 9 and older: direct.
 * [askUser] launches the dialog and runs the callback only if the user accepted.
 */
class FileOps(private val ctx: Context, private val askUser: (IntentSender, () -> Unit) -> Unit) {
    private val cr: ContentResolver get() = ctx.contentResolver

    private fun recoverable(e: SecurityException): IntentSender? =
        if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) e.userAction.actionIntent.intentSender else null

    private fun attempt(op: () -> Unit, done: (Boolean) -> Unit) {
        var sender: IntentSender? = null
        val ok = try { op(); true } catch (e: SecurityException) { sender = recoverable(e); false } catch (t: Throwable) { false }
        if (ok) { done(true); return }
        val s = sender
        if (s != null) askUser(s) {
            val ok2 = try { op(); true } catch (t: Throwable) { false }
            done(ok2)
        } else done(false)
    }

    fun delete(s: Video, done: (Boolean) -> Unit) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(cr, listOf(s.uri))
                askUser(pi.intentSender) { done(true) }
            } catch (t: Throwable) { done(false) }
        } else {
            attempt({
                cr.delete(s.uri, null, null)
                if (Build.VERSION.SDK_INT < 29 && s.path.isNotEmpty()) File(s.path).delete()
            }, done)
        }
    }

    fun rename(s: Video, base: String, done: (Boolean) -> Unit) {
        val clean = base.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (clean.isEmpty()) { done(false); return }
        val ext = s.fileName.substringAfterLast('.', "")
        val newName = if (ext.isEmpty()) clean else "$clean.$ext"
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, newName)
            put(MediaStore.Video.Media.TITLE, clean)
        }
        val op = {
            if (Build.VERSION.SDK_INT < 29 && s.path.isNotEmpty()) {
                val f = File(s.path)
                val nf = File(f.parentFile, newName)
                if (!f.renameTo(nf)) throw IOException("rename failed")
                v.put(MediaStore.MediaColumns.DATA, nf.absolutePath)
            }
            val n = cr.update(s.uri, v, null, null)
            if (n <= 0) throw IOException("nothing updated")
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createWriteRequest(cr, listOf(s.uri))
                askUser(pi.intentSender) { attempt(op, done) }
            } catch (t: Throwable) { done(false) }
        } else attempt(op, done)
    }
}
