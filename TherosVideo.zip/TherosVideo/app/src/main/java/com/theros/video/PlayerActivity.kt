package com.theros.video

import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : ComponentActivity(), PlayerHost {
    private lateinit var vp: VPlayer
    private lateinit var audio: AudioManager
    private var pipState by mutableStateOf(false)

    override val inPip: Boolean get() = pipState

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        hideBars()

        if (!resolveQueue(intent)) { finish(); return }
        vp = VPlayer(this)
        vp.onSize = { applyOrientation(Cfg.orient) }
        vp.playIndex(Queue.index, intent.getBooleanExtra("fromStart", false))
        applyOrientation(Cfg.orient)
        setContent { TherosTheme { PlayerScreen(vp, this) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (::vp.isInitialized && resolveQueue(intent)) vp.playIndex(Queue.index, intent.getBooleanExtra("fromStart", false))
    }

    /** Opened from the library (Queue already filled) or from another app ("Open with"). */
    private fun resolveQueue(i: Intent?): Boolean {
        val data = i?.data
        if (i?.action == Intent.ACTION_VIEW && data != null) {
            Queue.set(listOf(externalVideo(data)), 0)
            return true
        }
        return Queue.items.isNotEmpty()
    }

    private fun externalVideo(uri: Uri): Video {
        var name = uri.lastPathSegment ?: "Video"
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) name = n
                }
            }
        } catch (t: Throwable) { }
        val h = uri.toString().hashCode().toLong()
        val id = -abs(h) - 1L
        return Video(id, name.substringBeforeLast('.'), 0L, 0L, 0L, 0, 0, uri, "", name, "", "video/*")
    }

    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onResume() {
        super.onResume()
        hideBars()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (::vp.isInitialized && vp.isPlaying && Cfg.autoPip) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pipState = isInPictureInPictureMode
        if (!isInPictureInPictureMode) hideBars()
    }

    override fun onStop() {
        super.onStop()
        if (::vp.isInitialized) {
            vp.exo.pause()
            vp.persist()
        }
    }

    override fun onDestroy() {
        if (::vp.isInitialized) vp.release()
        super.onDestroy()
    }

    // ---------- PlayerHost ----------
    override fun brightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
        } catch (t: Throwable) { 0.5f }
    }

    override fun changeBrightness(v: Float) {
        val lp = window.attributes
        lp.screenBrightness = v.coerceIn(0.02f, 1f)
        window.attributes = lp
    }

    override fun volume(): Float {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    override fun changeVolume(f: Float) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, (f * max).roundToInt().coerceIn(0, max), 0) } catch (t: Throwable) { }
    }

    override fun enterPip() {
        if (Build.VERSION.SDK_INT < 26) return
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return
        val w = vp.videoW
        val h = vp.videoH
        val ratio = when {
            w <= 0 || h <= 0 -> Rational(16, 9)
            w.toFloat() / h > 2.39f -> Rational(239, 100)
            w.toFloat() / h < 0.42f -> Rational(100, 239)
            else -> Rational(w, h)
        }
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
        } catch (t: Throwable) { }
    }

    override fun applyOrientation(mode: Int) {
        requestedOrientation = when (mode) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            3 -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            else -> {
                val w = if (::vp.isInitialized) vp.videoW else 0
                val h = if (::vp.isInitialized) vp.videoH else 0
                when {
                    w > h && h > 0 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    h > w && w > 0 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }
            }
        }
    }

    override fun close() { finish() }
}
