package com.theros.video

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) sp = c.applicationContext.getSharedPreferences("theros_video_prefs", Context.MODE_PRIVATE)
    }

    fun int(k: String, d: Int): Int = sp?.getInt(k, d) ?: d
    fun long(k: String, d: Long): Long = sp?.getLong(k, d) ?: d
    fun bool(k: String, d: Boolean): Boolean = sp?.getBoolean(k, d) ?: d
    fun float(k: String, d: Float): Float = sp?.getFloat(k, d) ?: d
    fun str(k: String, d: String): String = sp?.getString(k, d) ?: d

    fun put(k: String, v: Any) {
        val e = sp?.edit() ?: return
        when (v) {
            is Int -> e.putInt(k, v)
            is Long -> e.putLong(k, v)
            is Boolean -> e.putBoolean(k, v)
            is Float -> e.putFloat(k, v)
            is String -> e.putString(k, v)
        }
        e.apply()
    }
}
