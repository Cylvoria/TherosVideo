package com.theros.video

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.*

/** The list of videos the player is currently stepping through. */
object Queue {
    var items: List<Video> = emptyList()
    var index: Int = 0

    fun set(list: List<Video>, i: Int) {
        items = list
        index = i.coerceIn(0, (list.size - 1).coerceAtLeast(0))
    }
}

/** User settings (all persisted in Prefs). */
object Cfg {
    var resume by mutableStateOf(true)
    var autoNext by mutableStateOf(true)
    var autoPip by mutableStateOf(true)
    var subBg by mutableStateOf(true)
    var seekSecs by mutableIntStateOf(10)
    var holdSpeed by mutableFloatStateOf(2f)
    var subSize by mutableFloatStateOf(1f)
    var orient by mutableIntStateOf(0)
    var aspect by mutableIntStateOf(0)

    fun load() {
        resume = Prefs.bool("c_resume", true)
        autoNext = Prefs.bool("c_next", true)
        autoPip = Prefs.bool("c_pip", true)
        subBg = Prefs.bool("c_subbg", true)
        seekSecs = Prefs.int("c_seek", 10).coerceIn(3, 60)
        holdSpeed = Prefs.float("c_hold", 2f).coerceIn(1.25f, 4f)
        subSize = Prefs.float("c_subsize", 1f).coerceIn(0.6f, 2.2f)
        orient = Prefs.int("c_orient", 0).coerceIn(0, 3)
        aspect = Prefs.int("c_aspect", 0).coerceIn(0, ResizeMode.values().size - 1)
    }

    fun save() {
        Prefs.put("c_resume", resume); Prefs.put("c_next", autoNext); Prefs.put("c_pip", autoPip)
        Prefs.put("c_subbg", subBg); Prefs.put("c_seek", seekSecs); Prefs.put("c_hold", holdSpeed)
        Prefs.put("c_subsize", subSize); Prefs.put("c_orient", orient); Prefs.put("c_aspect", aspect)
    }
}

/** Library state shared by the home screen. */
object Store {
    private lateinit var app: Context
    private val handler = Handler(Looper.getMainLooper())
    private var ready = false

    var videos by mutableStateOf<List<Video>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var scanNote by mutableStateOf(""); private set
    var sortKey by mutableStateOf(SortKey.ADDED); private set
    var sortAsc by mutableStateOf(false); private set
    var hideShort by mutableStateOf(false); private set
    var grid by mutableStateOf(true); private set
    var recent by mutableStateOf<List<Long>>(emptyList()); private set
    var tab by mutableIntStateOf(0)
    var folder by mutableStateOf<String?>(null)
    /** Bumped whenever watch progress changes so progress bars redraw. */
    var tick by mutableIntStateOf(0); private set

    fun init(ctx: Context) {
        if (ready) return
        ready = true
        app = ctx.applicationContext
        Prefs.init(app)
        ThemeState.load()
        Cfg.load()
        sortKey = SortKey.values().getOrElse(Prefs.int("v_sort", 0)) { SortKey.ADDED }
        sortAsc = Prefs.bool("v_asc", false)
        hideShort = Prefs.bool("v_hide", false)
        grid = Prefs.bool("v_grid", true)
        recent = Prefs.str("recent", "").split(',').mapNotNull { it.toLongOrNull() }
    }

    fun changeSort(k: SortKey, asc: Boolean) {
        sortKey = k; sortAsc = asc
        Prefs.put("v_sort", k.ordinal); Prefs.put("v_asc", asc)
    }

    fun changeHideShort(b: Boolean) { hideShort = b; Prefs.put("v_hide", b) }
    fun changeGrid(b: Boolean) { grid = b; Prefs.put("v_grid", b) }

    fun visible(): List<Video> =
        if (hideShort) videos.filter { !(it.duration in 1L until SHORT_MS) } else videos

    fun sorted(l: List<Video>): List<Video> {
        val c: Comparator<Video> = when (sortKey) {
            SortKey.TITLE -> Comparator { a, b -> a.title.compareTo(b.title, true) }
            SortKey.DURATION -> Comparator { a, b -> a.duration.compareTo(b.duration) }
            SortKey.SIZE -> Comparator { a, b -> a.size.compareTo(b.size) }
            SortKey.QUALITY -> Comparator { a, b -> minOf(a.width, a.height).compareTo(minOf(b.width, b.height)) }
            SortKey.ADDED -> Comparator { a, b -> a.added.compareTo(b.added) }
        }
        return if (sortAsc) l.sortedWith(c) else l.sortedWith(c.reversed())
    }

    /** Reads MediaStore, then walks storage for videos MediaStore missed and indexes them. */
    fun refresh() {
        if (loading) return
        loading = true
        scanNote = ""
        Thread {
            val t0 = SystemClock.uptimeMillis()
            var note: String
            try {
                val first = try { VideoLibrary.load(app) } catch (t: Throwable) { null }
                if (first != null) handler.post { videos = first }
                val known = HashSet<String>()
                first?.forEach { if (it.path.isNotEmpty()) known.add(it.path) }
                val added = try { Scanner.scanMissing(app, known) } catch (t: Throwable) { 0 }
                if (added > 0) {
                    val second = try { VideoLibrary.load(app) } catch (t: Throwable) { null }
                    if (second != null) handler.post { videos = second }
                    note = "Found $added new video" + (if (added == 1) "" else "s")
                } else note = "No new videos found"
            } catch (t: Throwable) {
                note = "Scan failed"
            }
            val rest = 700L - (SystemClock.uptimeMillis() - t0)
            if (rest > 0) try { Thread.sleep(rest) } catch (t: Throwable) { }
            handler.post { loading = false; scanNote = note }
        }.start()
    }

    // ---------- watch progress ----------
    fun savedPos(id: Long): Long = Prefs.long("pos_$id", 0L)
    fun savedDur(id: Long): Long = Prefs.long("dur_$id", 0L)

    fun markPlayed(id: Long, pos: Long, dur: Long) {
        val finished = dur > 0 && pos >= dur - 3000
        Prefs.put("pos_$id", if (finished) 0L else pos)
        if (dur > 0) Prefs.put("dur_$id", dur)
        if (id >= 0) {
            var l = recent.filter { it != id }
            if (!finished && pos > 3000) l = listOf(id) + l
            recent = l.take(12)
            Prefs.put("recent", recent.joinToString(","))
        }
        tick++
    }

    fun clearProgress(id: Long) {
        Prefs.put("pos_$id", 0L)
        recent = recent.filter { it != id }
        Prefs.put("recent", recent.joinToString(","))
        tick++
    }
}
