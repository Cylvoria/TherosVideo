package com.theros.video

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class FolderInfo(val name: String, val count: Int, val total: Long, val cover: Video)

@Composable
fun Thumb(v: Video, modifier: Modifier, shape: Shape) {
    val pal = LocalPal.current
    val ctx = LocalContext.current.applicationContext
    val bmp by produceState<Bitmap?>(initialValue = Thumbs.peek(v), v.id) {
        if (value == null) value = withContext(Dispatchers.IO) { Thumbs.get(ctx, v) }
    }
    Box(modifier.clip(shape).background(pal.card), Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Ic(R.drawable.ic_video, pal.subtle, 28.dp)
    }
}

@Composable
private fun Badge(text: String, modifier: Modifier = Modifier, accent: Boolean = false) {
    val pal = LocalPal.current
    Box(
        modifier.clip(RoundedCornerShape(6.dp))
            .background(if (accent) pal.accent else Color.Black.copy(alpha = 0.7f))
            .padding(horizontal = 6.dp, vertical = 2.dp),
    ) {
        Text(text, color = if (accent) pal.onAccent else Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun progressOf(v: Video): Float {
    @Suppress("UNUSED_VARIABLE") val t = Store.tick
    val d = if (v.duration > 0) v.duration else Store.savedDur(v.id)
    val p = Store.savedPos(v.id)
    return if (d > 0 && p > 3000) (p.toFloat() / d).coerceIn(0f, 1f) else 0f
}

@Composable
private fun ProgressBar(frac: Float, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    Box(modifier.fillMaxWidth().height(4.dp).background(Color.Black.copy(alpha = 0.45f))) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(frac.coerceIn(0.02f, 1f)).background(pal.accent))
    }
}

@Composable
private fun VideoCard(v: Video, onClick: () -> Unit, onLong: () -> Unit) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().bounceLong(onLong, onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
            Thumb(v, Modifier.fillMaxSize(), RoundedCornerShape(16.dp))
            val q = quality(v.width, v.height)
            if (q.isNotEmpty()) Badge(q, Modifier.align(Alignment.TopStart).padding(6.dp), true)
            Badge(fmt(v.duration), Modifier.align(Alignment.BottomEnd).padding(6.dp))
            val p = progressOf(v)
            if (p > 0f) ProgressBar(p, Modifier.align(Alignment.BottomStart))
        }
        Spacer(Modifier.height(6.dp))
        Text(v.title, color = pal.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text("${sizeText(v.size)} - ${v.folder}", color = pal.subtle, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun VideoRow(v: Video, onClick: () -> Unit, onLong: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).bounceLong(onLong, onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(136.dp).aspectRatio(16f / 9f)) {
            Thumb(v, Modifier.fillMaxSize(), RoundedCornerShape(14.dp))
            Badge(fmt(v.duration), Modifier.align(Alignment.BottomEnd).padding(5.dp))
            val p = progressOf(v)
            if (p > 0f) ProgressBar(p, Modifier.align(Alignment.BottomStart))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(v.title, color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val q = quality(v.width, v.height)
            Text(
                (if (q.isNotEmpty()) "$q - " else "") + sizeText(v.size),
                color = pal.accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            )
            Text(v.folder, color = pal.subtle, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun FolderRow(f: FolderInfo, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).bounceClick(onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(120.dp).aspectRatio(16f / 9f)) {
            Thumb(f.cover, Modifier.fillMaxSize(), RoundedCornerShape(14.dp))
            Box(Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(alpha = 0.25f)))
            Ic(R.drawable.ic_folder, Color.White, 26.dp, Modifier.align(Alignment.Center))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${f.count} video" + (if (f.count == 1) "" else "s") + " - " + fmt(f.total), color = pal.subtle, fontSize = 12.sp)
        }
    }
}

@Composable
private fun RecentRow(vids: List<Video>, onPlay: (Int) -> Unit, onLong: (Video) -> Unit) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp)) {
        Text("Continue watching", color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(vids.size) { i ->
                val v = vids[i]
                Column(Modifier.width(210.dp).bounceLong({ onLong(v) }, { onPlay(i) })) {
                    Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                        Thumb(v, Modifier.fillMaxSize(), RoundedCornerShape(16.dp))
                        Box(
                            Modifier.align(Alignment.Center).size(40.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)),
                            Alignment.Center,
                        ) { Ic(R.drawable.ic_play, Color.White, 22.dp) }
                        val d = if (v.duration > 0) v.duration else Store.savedDur(v.id)
                        val left = d - Store.savedPos(v.id)
                        if (left > 0) Badge(fmt(left) + " left", Modifier.align(Alignment.TopEnd).padding(6.dp))
                        val p = progressOf(v)
                        if (p > 0f) ProgressBar(p, Modifier.align(Alignment.BottomStart))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(v.title, color = pal.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onTheme: () -> Unit, onSort: () -> Unit, onSettings: () -> Unit, ops: FileOps,
    play: (List<Video>, Int, Boolean) -> Unit,
) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var menuVideo by remember { mutableStateOf<Video?>(null) }
    var renameVideo by remember { mutableStateOf<Video?>(null) }
    var deleteVideo by remember { mutableStateOf<Video?>(null) }
    var infoVideo by remember { mutableStateOf<Video?>(null) }

    val base = remember(Store.videos, Store.hideShort) { Store.visible() }
    val list = remember(base, Store.sortKey, Store.sortAsc, query, Store.folder) {
        val q = query.trim()
        var l = base
        val f = Store.folder
        if (f != null) l = l.filter { it.folder == f }
        if (q.isNotEmpty()) l = l.filter { it.title.contains(q, true) || it.folder.contains(q, true) }
        Store.sorted(l)
    }
    val folders = remember(base) {
        base.groupBy { it.folder }
            .map { (n, vs) -> FolderInfo(n, vs.size, vs.sumOf { it.duration }, vs.first()) }
            .sortedBy { it.name.lowercase() }
    }
    val recentVideos = remember(Store.recent, Store.videos) {
        Store.recent.mapNotNull { id -> Store.videos.firstOrNull { it.id == id } }
    }
    val spin by rememberInfiniteTransition(label = "spin").animateFloat(
        0f, 360f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "spin",
    )
    val bottomPad = 32.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val showFolders = Store.tab == 1 && Store.folder == null && query.isEmpty()
    val showRecent = Store.tab == 0 && Store.folder == null && query.isEmpty() && recentVideos.isNotEmpty()
    fun toast(m: String) { Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show() }

    BackHandler(Store.folder != null) { Store.folder = null }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Theros Video", Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = TextStyle(brush = pal.hBrush, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold),
            )
            RoundBtn(if (searching) R.drawable.ic_close else R.drawable.ic_search, { searching = !searching; if (!searching) query = "" }, size = 42.dp)
            Spacer(Modifier.width(8.dp))
            RoundBtn(R.drawable.ic_settings, onSettings, size = 42.dp)
            Spacer(Modifier.width(8.dp))
            RoundBtn(R.drawable.ic_palette, onTheme, size = 42.dp, filled = true)
        }
        AnimatedVisibility(searching) {
            TextField(
                query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                placeholder = { Text("Search videos and folders", color = pal.subtle) },
                singleLine = true, shape = CircleShape,
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedContainerColor = pal.card, unfocusedContainerColor = pal.card,
                    focusedTextColor = pal.text, unfocusedTextColor = pal.text, cursorColor = pal.accent,
                ),
            )
        }

        // tabs + view controls
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            val f = Store.folder
            if (f != null) {
                Chip("Back", false, { Store.folder = null }, icon = R.drawable.ic_back)
                Spacer(Modifier.width(10.dp))
                Text(f, Modifier.weight(1f), color = pal.text, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            } else {
                Chip("Videos", Store.tab == 0, { Store.tab = 0 }, icon = R.drawable.ic_video)
                Spacer(Modifier.width(8.dp))
                Chip("Folders", Store.tab == 1, { Store.tab = 1 }, icon = R.drawable.ic_folder)
                Spacer(Modifier.weight(1f))
            }
            RoundBtn(if (Store.grid) R.drawable.ic_list else R.drawable.ic_grid, { Store.changeGrid(!Store.grid) }, size = 38.dp, iconSize = 20.dp)
            Spacer(Modifier.width(6.dp))
            RoundBtn(R.drawable.ic_sort, onSort, size = 38.dp, iconSize = 20.dp)
            Spacer(Modifier.width(6.dp))
            RoundBtn(R.drawable.ic_refresh, { Store.refresh() }, size = 38.dp, iconSize = 20.dp, modifier = Modifier.rotate(if (Store.loading) spin else 0f))
        }

        // status + hide short
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Switch(
                Store.hideShort, { Store.changeHideShort(it) }, Modifier.scale(0.72f),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = pal.onAccent, checkedTrackColor = pal.accent,
                    uncheckedThumbColor = pal.subtle, uncheckedTrackColor = pal.card,
                ),
            )
            Column(Modifier.weight(1f)) {
                Text("Hide short clips", color = pal.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    when {
                        Store.loading -> "Scanning storage..."
                        Store.scanNote.isNotEmpty() -> Store.scanNote
                        Store.hideShort -> "On: under ${SHORT_MS / 1000}s hidden"
                        else -> "Off: showing everything"
                    },
                    color = pal.subtle, fontSize = 11.sp,
                )
            }
            Text(
                if (showFolders) "${folders.size} folders" else "${list.size} videos",
                color = pal.subtle, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            )
        }

        PullToRefreshBox(isRefreshing = Store.loading, onRefresh = { Store.refresh() }, modifier = Modifier.fillMaxSize()) {
            when {
                showFolders && folders.isNotEmpty() -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 6.dp, bottom = bottomPad)) {
                    items(folders, key = { it.name }) { f ->
                        FolderRow(f) { Store.folder = f.name; Store.tab = 0 }
                    }
                }
                list.isEmpty() && !showFolders -> EmptyState(query.isNotEmpty(), Store.loading, Store.videos.isNotEmpty() && Store.hideShort)
                showFolders -> EmptyState(false, Store.loading, false)
                Store.grid -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(170.dp), modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = bottomPad),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    if (showRecent) item(span = { GridItemSpan(maxLineSpan) }) {
                        RecentRow(recentVideos, { i -> play(recentVideos, i, false) }, { menuVideo = it })
                    }
                    items(list, key = { it.id }) { v ->
                        VideoCard(v, { play(list, list.indexOf(v), false) }, { menuVideo = v })
                    }
                }
                else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 6.dp, bottom = bottomPad)) {
                    if (showRecent) item {
                        Box(Modifier.padding(horizontal = 14.dp)) {
                            RecentRow(recentVideos, { i -> play(recentVideos, i, false) }, { menuVideo = it })
                        }
                    }
                    items(list, key = { it.id }) { v ->
                        VideoRow(v, { play(list, list.indexOf(v), false) }, { menuVideo = v })
                    }
                }
            }
        }
    }

    menuVideo?.let { v ->
        val hasProgress = remember(v.id, Store.tick) { Store.savedPos(v.id) > 3000 }
        VideoMenuSheet(
            video = v, hasProgress = hasProgress, onDismiss = { menuVideo = null },
            onPlay = { menuVideo = null; val i = list.indexOfFirst { it.id == v.id }; if (i >= 0) play(list, i, false) else play(listOf(v), 0, false) },
            onFromStart = { menuVideo = null; val i = list.indexOfFirst { it.id == v.id }; if (i >= 0) play(list, i, true) else play(listOf(v), 0, true) },
            onClearProgress = { menuVideo = null; Store.clearProgress(v.id); toast("Progress cleared") },
            onRename = { menuVideo = null; renameVideo = v },
            onShare = {
                menuVideo = null
                try {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "video/*"
                        putExtra(Intent.EXTRA_STREAM, v.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(Intent.createChooser(i, "Share video"))
                } catch (t: Throwable) { toast("Can't share this file") }
            },
            onInfo = { menuVideo = null; infoVideo = v },
            onDelete = { menuVideo = null; deleteVideo = v },
        )
    }
    renameVideo?.let { v ->
        RenameDialog(v, { renameVideo = null }) { name ->
            renameVideo = null
            ops.rename(v, name) { ok ->
                toast(if (ok) "Renamed" else "Couldn't rename this file")
                if (ok) Store.refresh()
            }
        }
    }
    deleteVideo?.let { v ->
        DeleteDialog(v, { deleteVideo = null }) {
            deleteVideo = null
            ops.delete(v) { ok ->
                if (ok) { toast("Deleted"); Store.refresh() } else toast("Couldn't delete this file")
            }
        }
    }
    infoVideo?.let { v -> InfoDialog(v) { infoVideo = null } }
}

@Composable
private fun EmptyState(searching: Boolean, loading: Boolean, onlyShort: Boolean) {
    val pal = LocalPal.current
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Ic(R.drawable.ic_video, pal.subtle, 56.dp)
        Spacer(Modifier.height(12.dp))
        Text(
            when {
                loading -> "Scanning..."
                searching -> "No matches"
                onlyShort -> "Only short clips found"
                else -> "No videos found"
            },
            color = pal.text, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        )
        Text("Pull down or tap refresh to rescan your storage", color = pal.subtle, fontSize = 13.sp)
    }
}
