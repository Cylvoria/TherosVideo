package com.theros.video

import android.net.Uri

data class Video(
    val id: Long,
    val title: String,
    val duration: Long,
    val added: Long,
    val size: Long,
    val width: Int,
    val height: Int,
    val uri: Uri,
    val path: String,
    val fileName: String,
    val folder: String,
    val mime: String,
)

/** Clips shorter than this are treated as "short clips" by the hide-short toggle. */
const val SHORT_MS = 10_000L

enum class SortKey(val label: String) {
    ADDED("Date added"), TITLE("Title"), DURATION("Duration"), SIZE("File size"), QUALITY("Resolution")
}

enum class ResizeMode(val label: String) {
    FIT("Fit"), FILL("Stretch"), ZOOM("Zoom"), R169("16:9"), R43("4:3")
}

fun fmt(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    val h = t / 3600
    val m = (t % 3600) / 60
    val s = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun quality(w: Int, h: Int): String {
    val s = minOf(w, h)
    return when {
        s <= 0 -> ""
        s >= 2160 -> "4K"
        s >= 1440 -> "2K"
        s >= 1080 -> "1080p"
        s >= 720 -> "720p"
        s >= 480 -> "480p"
        else -> "SD"
    }
}

fun sizeText(b: Long): String =
    if (b >= 1073741824L) "%.2f GB".format(b / 1073741824.0) else "%.1f MB".format(b / 1048576.0)
