package com.theros.video

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(this)
        setContent { TherosTheme { AppRoot() } }
    }
}

fun mediaPerm(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

private class GrantHolder { var op: (() -> Unit)? = null }

@Composable
fun AppRoot() {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    var showTheme by rememberSaveable { mutableStateOf(false) }
    var showSort by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var granted by remember { mutableStateOf(has(mediaPerm())) }
    var crashText by remember { mutableStateOf(Crash.take(ctx)) }
    val grant = remember { GrantHolder() }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = has(mediaPerm())
        if (granted) Store.refresh()
    }

    // System "allow this change?" dialogs for rename / delete (Android 10+)
    val grantLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val op = grant.op
        grant.op = null
        if (r.resultCode == Activity.RESULT_OK) op?.invoke()
    }
    val ops = remember {
        FileOps(ctx) { sender, after ->
            grant.op = after
            try { grantLauncher.launch(IntentSenderRequest.Builder(sender).build()) } catch (t: Throwable) { grant.op = null }
        }
    }

    LaunchedEffect(Unit) {
        if (!granted) permLauncher.launch(mediaPerm()) else Store.refresh()
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = has(mediaPerm())
        if (granted && Store.videos.isEmpty() && !Store.loading) Store.refresh()
    }

    val play: (List<Video>, Int, Boolean) -> Unit = { list, index, fromStart ->
        Queue.set(list, index)
        ctx.startActivity(Intent(ctx, PlayerActivity::class.java).putExtra("fromStart", fromStart))
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(pal.bg, pal.surface)))) {
        if (!granted) PermissionScreen(
            onGrant = { permLauncher.launch(mediaPerm()) },
            onSettings = {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)))
            },
        ) else HomeScreen(
            onTheme = { showTheme = true }, onSort = { showSort = true }, onSettings = { showSettings = true },
            ops = ops, play = play,
        )
    }

    if (showSort) SortSheet { showSort = false }
    if (showTheme) ThemeSheet { showTheme = false }
    if (showSettings) SettingsSheet { showSettings = false }

    crashText?.let { t ->
        AlertDialog(
            onDismissRequest = { crashText = null },
            containerColor = pal.surface, titleContentColor = pal.text, textContentColor = pal.text,
            title = { Text("Theros Video crashed last time", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Copy this error and send it so it can be fixed:", color = pal.subtle, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(t, color = pal.text, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            },
            confirmButton = {
                TextButton({
                    try {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("crash", t))
                        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                    } catch (e: Throwable) { }
                }) { Text("Copy", color = pal.accent, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton({ crashText = null }) { Text("Close", color = pal.subtle) } },
        )
    }
}

@Composable
fun PermissionScreen(onGrant: () -> Unit, onSettings: () -> Unit) {
    val pal = LocalPal.current
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(pal.brush), Alignment.Center) {
            Ic(R.drawable.ic_video, pal.onAccent, 44.dp)
        }
        Spacer(Modifier.height(24.dp))
        Text("Let Theros Video find your videos", color = pal.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            "Theros Video only reads video files on your device. No ads, no accounts, no internet.",
            color = pal.subtle, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        Chip("Allow access", true, onGrant)
        Spacer(Modifier.height(10.dp))
        Chip("Open app settings", false, onSettings)
    }
}
