package com.theros.video

import android.graphics.Bitmap
import android.graphics.Color as AColor
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

@Composable
fun Ic(res: Int, tint: Color = LocalPal.current.text, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Icon(painterResource(res), null, modifier.size(size), tint)
}

fun Modifier.bounceClick(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.93f else 1f, spring(0.5f, 500f), label = "bounce")
    this.graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** Tap = onClick, press-and-hold = onLong (with a haptic tick). Same bounce animation as bounceClick. */
fun Modifier.bounceLong(onLong: () -> Unit, onClick: () -> Unit): Modifier = composed {
    var pressed by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (pressed) 0.96f else 1f, spring(0.5f, 500f), label = "bounceLong")
    val click by rememberUpdatedState(onClick)
    val long by rememberUpdatedState(onLong)
    val haptic = LocalHapticFeedback.current
    this.graphicsLayer { scaleX = sc; scaleY = sc }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                onTap = { click() },
                onLongPress = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    long()
                },
            )
        }
}

@Composable
fun RoundBtn(
    res: Int, onClick: () -> Unit, modifier: Modifier = Modifier, size: Dp = 44.dp,
    filled: Boolean = false, tint: Color? = null, iconSize: Dp = 22.dp,
) {
    val pal = LocalPal.current
    Box(
        modifier.size(size).bounceClick(onClick).clip(CircleShape)
            .then(if (filled) Modifier.background(pal.brush) else Modifier.background(pal.card)),
        Alignment.Center,
    ) { Ic(res, tint ?: if (filled) pal.onAccent else pal.text, iconSize) }
}

@Composable
fun SeekBar(value: Float, onSeek: (Float) -> Unit, onSeekEnd: () -> Unit, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    var w by remember { mutableIntStateOf(1) }
    val seek by rememberUpdatedState(onSeek)
    val end by rememberUpdatedState(onSeekEnd)
    Box(
        modifier.fillMaxWidth().height(34.dp).onSizeChanged { w = it.width.coerceAtLeast(1) }
            .pointerInput(Unit) { detectTapGestures { seek((it.x / w).coerceIn(0f, 1f)); end() } }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { seek((it.x / w).coerceIn(0f, 1f)) },
                    onDragEnd = { end() }, onDragCancel = { end() },
                ) { change, _ -> seek((change.position.x / w).coerceIn(0f, 1f)) }
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val th = 6.dp.toPx()
            val y = (size.height - th) / 2f
            drawRoundRect(pal.text.copy(.16f), Offset(0f, y), Size(size.width, th), CornerRadius(th / 2))
            val aw = size.width * value.coerceIn(0f, 1f)
            if (aw > 0f) drawRoundRect(
                Brush.horizontalGradient(listOf(pal.accent, pal.accent2), 0f, size.width),
                Offset(0f, y), Size(aw, th), CornerRadius(th / 2),
            )
            drawCircle(pal.accent2.copy(.25f), 13.dp.toPx(), Offset(aw, size.height / 2f))
            drawCircle(Color.White, 8.dp.toPx(), Offset(aw, size.height / 2f))
            drawCircle(pal.accent2, 4.5.dp.toPx(), Offset(aw, size.height / 2f))
        }
    }
}

/** HSV colour wheel: hue around, saturation outward. */
@Composable
fun ColorWheel(color: Int, onColor: (Int) -> Unit, modifier: Modifier = Modifier) {
    var w by remember { mutableIntStateOf(1) }
    val cur by rememberUpdatedState(color)
    val cb by rememberUpdatedState(onColor)
    val hsv = FloatArray(3).also { AColor.colorToHSV(color, it) }
    fun pick(o: Offset) {
        val c = w / 2f
        val dx = o.x - c; val dy = o.y - c
        val r = min(hypot(dx, dy), c)
        var ang = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
        if (ang < 0) ang += 360f
        val v = FloatArray(3).also { AColor.colorToHSV(cur, it) }
        cb(AColor.HSVToColor(floatArrayOf(ang, (r / c).coerceIn(0f, 1f), max(v[2], 0.3f))))
    }
    Canvas(
        modifier.aspectRatio(1f).onSizeChanged { w = it.width.coerceAtLeast(1) }
            .pointerInput(Unit) { detectTapGestures { pick(it) } }
            .pointerInput(Unit) { detectDragGestures(onDragStart = { pick(it) }) { ch, _ -> pick(ch.position) } },
    ) {
        val c = size.width / 2f
        val ctr = Offset(c, c)
        val hues = (0..6).map { Color(AColor.HSVToColor(floatArrayOf((it * 60f) % 360f, 1f, 1f))) }
        drawCircle(Brush.sweepGradient(hues, ctr), c, ctr)
        drawCircle(Brush.radialGradient(listOf(Color.White, Color.Transparent), ctr, c), c, ctr)
        drawCircle(Color.Black.copy(alpha = (1f - hsv[2]).coerceIn(0f, 0.7f)), c, ctr)
        val a = Math.toRadians(hsv[0].toDouble())
        val p = Offset(ctr.x + (cos(a) * hsv[1] * c).toFloat(), ctr.y + (sin(a) * hsv[1] * c).toFloat())
        drawCircle(Color.White, 13.dp.toPx(), p)
        drawCircle(Color(color), 9.dp.toPx(), p)
    }
}
