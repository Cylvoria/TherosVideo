package com.theros.video

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val DANGER = Color(0xFFFF5252)

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, icon: Int? = null) {
    val pal = LocalPal.current
    Row(
        modifier.bounceClick(onClick).clip(CircleShape)
            .then(if (selected) Modifier.background(pal.brush) else Modifier.background(pal.card))
            .padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) { Ic(icon, if (selected) pal.onAccent else pal.text, 18.dp); Spacer(Modifier.width(6.dp)) }
        Text(text, color = if (selected) pal.onAccent else pal.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Swatch(brush: Brush, selected: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    val sc by animateFloatAsState(if (selected) 1.1f else 1f, spring(0.5f, 400f), label = "sw")
    Box(
        Modifier.size(50.dp).graphicsLayer { scaleX = sc; scaleY = sc }.bounceClick(onClick).clip(CircleShape)
            .background(brush).then(if (selected) Modifier.border(3.dp, pal.text, CircleShape) else Modifier),
        Alignment.Center,
    ) { if (selected) Ic(R.drawable.ic_check, Color.White, 22.dp) }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ThemeSheet(onDismiss: () -> Unit) {
    val pal = LocalPal.current
    var editB by remember { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = pal.surface, sheetState = rememberModalBottomSheetState(true)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp).verticalScroll(rememberScrollState())) {
            Text("Theme", color = pal.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Presets" to ThemeMode.PRESET, "Gradients" to ThemeMode.GRADIENT, "Color wheel" to ThemeMode.WHEEL)
                    .forEach { (n, m) -> Chip(n, ThemeState.mode == m, { ThemeState.mode = m; ThemeState.commit() }) }
            }
            Spacer(Modifier.height(18.dp))
            when (ThemeState.mode) {
                ThemeMode.PRESET -> FlowRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    PRESETS.forEachIndexed { i, p ->
                        Swatch(Brush.linearGradient(listOf(Color(p.second), Color(p.second).copy(alpha = .75f))), ThemeState.presetIdx == i) {
                            ThemeState.presetIdx = i; ThemeState.commit()
                        }
                    }
                }
                ThemeMode.GRADIENT -> FlowRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    GRADS.forEachIndexed { i, g ->
                        Swatch(Brush.linearGradient(listOf(Color(g.second), Color(g.third))), ThemeState.gradIdx == i) {
                            ThemeState.gradIdx = i; ThemeState.commit()
                        }
                    }
                }
                ThemeMode.WHEEL -> Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Swatch(SolidColor(Color(ThemeState.wheelA)), !editB) { editB = false }
                        if (ThemeState.wheelGradient) Swatch(SolidColor(Color(ThemeState.wheelB)), editB) { editB = true }
                        Spacer(Modifier.width(8.dp))
                        Text("Gradient", color = pal.subtle, fontSize = 13.sp)
                        Switch(
                            ThemeState.wheelGradient,
                            { ThemeState.wheelGradient = it; if (!it) editB = false; ThemeState.commit() },
                            colors = SwitchDefaults.colors(checkedTrackColor = pal.accent, checkedThumbColor = pal.onAccent),
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    val c = if (editB) ThemeState.wheelB else ThemeState.wheelA
                    ColorWheel(c, {
                        if (editB) ThemeState.wheelB = it else ThemeState.wheelA = it
                        ThemeState.mode = ThemeMode.WHEEL; ThemeState.commit()
                    }, Modifier.widthIn(max = 280.dp).fillMaxWidth(0.8f))
                    val hsv = FloatArray(3).also { android.graphics.Color.colorToHSV(c, it) }
                    Text("Brightness", color = pal.subtle, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                    Slider(
                        value = hsv[2].coerceIn(0.3f, 1f), valueRange = 0.3f..1f,
                        onValueChange = {
                            val n = android.graphics.Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], it))
                            if (editB) ThemeState.wheelB = n else ThemeState.wheelA = n
                            ThemeState.mode = ThemeMode.WHEEL
                        },
                        onValueChangeFinished = { ThemeState.commit() },
                        colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent, inactiveTrackColor = pal.accent.copy(.22f)),
                    )
                }
            }
            Spacer(Modifier.height(22.dp))
            Text("Appearance", color = pal.text, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("System" to DarkMode.SYSTEM, "Dark" to DarkMode.DARK, "Light" to DarkMode.LIGHT)
                    .forEach { (n, m) -> Chip(n, ThemeState.dark == m, { ThemeState.dark = m; ThemeState.commit() }) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SortSheet(onDismiss: () -> Unit) {
    val pal = LocalPal.current
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = pal.surface, sheetState = rememberModalBottomSheetState(true)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Text("Sort by", color = pal.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
            SortKey.values().forEach { k ->
                val sel = Store.sortKey == k
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(18.dp))
                        .then(if (sel) Modifier.background(pal.accent.copy(.16f)) else Modifier)
                        .bounceClick {
                            if (sel) Store.changeSort(k, !Store.sortAsc)
                            else Store.changeSort(k, k == SortKey.TITLE)
                        }.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(k.label, Modifier.weight(1f), color = if (sel) pal.accent else pal.text, fontWeight = FontWeight.SemiBold)
                    if (sel) Ic(if (Store.sortAsc) R.drawable.ic_arrow_up else R.drawable.ic_arrow_down, pal.accent, 20.dp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip("Ascending", Store.sortAsc, { Store.changeSort(Store.sortKey, true) }, icon = R.drawable.ic_arrow_up)
                Chip("Descending", !Store.sortAsc, { Store.changeSort(Store.sortKey, false) }, icon = R.drawable.ic_arrow_down)
            }
        }
    }
}

@Composable
private fun SettingToggle(label: String, sub: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = pal.subtle, fontSize = 12.sp)
        }
        Switch(
            checked, { onChecked(it); Cfg.save() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = pal.onAccent, checkedTrackColor = pal.accent,
                uncheckedThumbColor = pal.subtle, uncheckedTrackColor = pal.card,
            ),
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    val pal = LocalPal.current
    Spacer(Modifier.height(18.dp))
    Text(text, color = pal.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(Modifier.height(8.dp))
}

/** Playback settings. Used from the home screen and from the player's menu. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsSheet(onDismiss: () -> Unit) {
    val pal = LocalPal.current
    DisposableEffect(Unit) { onDispose { Cfg.save() } }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = pal.surface, sheetState = rememberModalBottomSheetState(true)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp).verticalScroll(rememberScrollState())) {
            Text("Settings", color = pal.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)

            SectionTitle("Playback")
            SettingToggle("Resume where you left off", "Pick up each video from its last position", Cfg.resume) { Cfg.resume = it }
            SettingToggle("Play next video automatically", "Continue with the next video in the list", Cfg.autoNext) { Cfg.autoNext = it }
            SettingToggle("Picture-in-picture", "Keep playing in a small window when you leave the app", Cfg.autoPip) { Cfg.autoPip = it }

            SectionTitle("Double-tap skip")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(5, 10, 15, 30).forEach { s -> Chip("${s}s", Cfg.seekSecs == s, { Cfg.seekSecs = s; Cfg.save() }) }
            }

            SectionTitle("Hold screen to speed up")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1.5f, 2f, 3f, 4f).forEach { s ->
                    Chip(if (s % 1f == 0f) "${s.toInt()}x" else "${s}x", Cfg.holdSpeed == s, { Cfg.holdSpeed = s; Cfg.save() })
                }
            }

            SectionTitle("Subtitles")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Size", Modifier.weight(1f), color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text("${(Cfg.subSize * 100).roundToInt()}%", color = pal.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = Cfg.subSize, valueRange = 0.6f..2.2f,
                onValueChange = { Cfg.subSize = it }, onValueChangeFinished = { Cfg.save() },
                colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent, inactiveTrackColor = pal.accent.copy(alpha = 0.22f)),
            )
            SettingToggle("Dark background", "Makes subtitles easier to read", Cfg.subBg) { Cfg.subBg = it }

            SectionTitle("Gestures")
            Text(
                "Swipe up/down on the left side: brightness\nSwipe up/down on the right side: volume\nSwipe left/right: seek\n" +
                    "Double-tap left/right: skip back/forward\nDouble-tap middle: play/pause\nHold: temporary fast playback\nPinch: zoom to fill / fit",
                color = pal.subtle, fontSize = 13.sp, lineHeight = 19.sp,
            )
        }
    }
}

@Composable
private fun MenuRow(icon: Int, label: String, tint: Color? = null, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(18.dp))
            .bounceClick(onClick).padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Ic(icon, tint ?: pal.text, 22.dp)
        Spacer(Modifier.width(16.dp))
        Text(label, color = tint ?: pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Bottom sheet shown when you press and hold a video. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoMenuSheet(
    video: Video, hasProgress: Boolean, onDismiss: () -> Unit, onPlay: () -> Unit, onFromStart: () -> Unit,
    onClearProgress: () -> Unit, onRename: () -> Unit, onShare: () -> Unit, onInfo: () -> Unit, onDelete: () -> Unit,
) {
    val pal = LocalPal.current
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = pal.surface, sheetState = rememberModalBottomSheetState(true)) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp).verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Thumb(video, Modifier.width(96.dp).aspectRatio(16f / 9f), RoundedCornerShape(14.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(video.title, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("${fmt(video.duration)} - ${sizeText(video.size)}", color = pal.subtle, fontSize = 13.sp, maxLines = 1)
                }
            }
            Spacer(Modifier.height(8.dp))
            MenuRow(R.drawable.ic_play, if (hasProgress) "Resume" else "Play", onClick = onPlay)
            if (hasProgress) {
                MenuRow(R.drawable.ic_replay, "Play from start", onClick = onFromStart)
                MenuRow(R.drawable.ic_close, "Clear watch progress", onClick = onClearProgress)
            }
            MenuRow(R.drawable.ic_edit, "Rename file", onClick = onRename)
            MenuRow(R.drawable.ic_share, "Share", onClick = onShare)
            MenuRow(R.drawable.ic_info, "Details", onClick = onInfo)
            MenuRow(R.drawable.ic_delete, "Delete from phone", DANGER, onDelete)
        }
    }
}

@Composable
fun RenameDialog(video: Video, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    val pal = LocalPal.current
    var text by remember { mutableStateOf(video.fileName.substringBeforeLast('.').ifBlank { video.title }) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = pal.surface, titleContentColor = pal.text, textContentColor = pal.text,
        title = { Text("Rename", fontWeight = FontWeight.ExtraBold) },
        text = {
            TextField(
                text, { text = it }, singleLine = true, shape = RoundedCornerShape(16.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedContainerColor = pal.card, unfocusedContainerColor = pal.card,
                    focusedTextColor = pal.text, unfocusedTextColor = pal.text, cursorColor = pal.accent,
                ),
            )
        },
        confirmButton = { TextButton({ onConfirm(text) }) { Text("Rename", color = pal.accent, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = pal.subtle) } },
    )
}

@Composable
fun DeleteDialog(video: Video, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    val pal = LocalPal.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = pal.surface, titleContentColor = pal.text, textContentColor = pal.text,
        title = { Text("Delete this video?", fontWeight = FontWeight.ExtraBold) },
        text = { Text("\"${video.title}\" will be permanently deleted from your phone.", color = pal.subtle) },
        confirmButton = { TextButton(onConfirm) { Text("Delete", color = DANGER, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = pal.subtle) } },
    )
}

@Composable
private fun InfoLine(label: String, value: String) {
    val pal = LocalPal.current
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, color = pal.subtle, fontSize = 11.sp)
        Text(value, color = pal.text, fontSize = 14.sp)
    }
}

@Composable
fun InfoDialog(video: Video, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = pal.surface, titleContentColor = pal.text, textContentColor = pal.text,
        title = { Text("Details", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                InfoLine("Title", video.title)
                InfoLine("Length", fmt(video.duration))
                if (video.width > 0) InfoLine("Resolution", "${video.width} x ${video.height}  ${quality(video.width, video.height)}")
                InfoLine("Size", sizeText(video.size))
                InfoLine("Folder", video.folder)
                if (video.fileName.isNotEmpty()) InfoLine("File name", video.fileName)
                if (video.mime.isNotEmpty()) InfoLine("Type", video.mime)
                if (video.path.isNotEmpty()) InfoLine("Location", video.path)
                if (video.added > 0) InfoLine("Added", java.text.DateFormat.getDateTimeInstance().format(java.util.Date(video.added * 1000)))
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close", color = pal.accent, fontWeight = FontWeight.Bold) } },
    )
}
