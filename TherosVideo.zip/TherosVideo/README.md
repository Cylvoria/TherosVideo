# Theros Video - clean, ad-free local video player (Android 7 to 16+)

Build on your phone with GitHub Actions:
1. Create a new GitHub repo and upload `TherosVideo.zip` (or its extracted files), commit to main.
2. Make sure `.github/workflows/build.yml` exists at the top of the repo (create it with "Add file > Create new file" if needed).
3. Actions tab -> latest run -> Artifacts -> `TherosVideo-apk`.
